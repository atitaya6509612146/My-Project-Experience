package th.ac.tu.cs.subjectRequestForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubjectRequestFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
