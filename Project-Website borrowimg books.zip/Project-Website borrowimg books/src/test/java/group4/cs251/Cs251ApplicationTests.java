package group4.cs251;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs251ApplicationTests {

	@Test
	void contextLoads() {
	}

}
