package group4.cs251;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cs251Application {

	public static void main(String[] args) {
		SpringApplication.run(Cs251Application.class, args);
	}

}
